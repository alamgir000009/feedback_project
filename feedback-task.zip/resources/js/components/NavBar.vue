<template>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <router-link class="navbar-brand" to="/">Logo</router-link>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <router-link class="nav-link" to="/register">Register</router-link>
        </li>
        <li v-if="!isLoggedIn" class="nav-item">
          <router-link class="nav-link" to="/login">Login</router-link>
        </li>
        <li v-else class="nav-item">
          <a class="nav-link" href="#" @click="logout()">Log out</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</template>

<script>

export default {
    name: 'NavBar',
    data() {
        return {
            isLoggedIn: false,
        }
    },
    methods:{
        async logout()
        {
            await this.axios.post('user/logout').then(() => {
                localStorage.removeItem('auth_token');
            }).catch(() => {
                localStorage.removeItem('auth_token');
            }).finally(() => {
                this.$router.push('/login');
            });
        },
    },
    mounted() {
        this.isLoggedIn = localStorage.getItem('auth_token') !== null;
    }
}

</script>