import { createRouter, createWebHistory } from 'vue-router';

import Landing from './views/Landing.vue';
import Register from './views/Register.vue';
import Login from './views/Login.vue';
import Home from './views/Home.vue';


const router = createRouter({
    history: createWebHistory(),
    routes: [
        // Frontend routes
        { path: '/', component: Landing, name: Landing, meta: { loginRequired: false } },
        { path: '/register', component: Register, name: Register, meta: { loginRequired: false } },
        { path: '/login', component: Login, name: Login, meta: { loginRequired: false } },

        { path: '/home', component: Home, name: Home, meta: { loginRequired: true } },
    ],
});
router.beforeEach((to, from, next) => {
    const isLoggedIn = localStorage.getItem('auth_token') !== null;
    if (to.meta.loginRequired && !isLoggedIn) {
        next('/login');
    }
    else {
        next();
    }
});
export default router;
