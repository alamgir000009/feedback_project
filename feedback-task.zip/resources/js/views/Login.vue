<template>
    <NavBar />
    <div class="container mt-4">
        <div class="col-md-8 mx-auto">
            <div class="card bg-white">
                <div class="card-heading">
                    <h3 class="card-title">Login</h3>
                </div>
                <div class="card-body">
                    <form @submit.prevent="login()">
                        <div class="form-group mt-3">
                            <input
                                type="email"
                                class="form-control input-sm"
                                placeholder="Email Address"
                                v-model="formData.email"
                            />
                        </div>
                        <div class="form-group mt-3">
                            <input
                                type="password"
                                class="form-control input-sm"
                                placeholder="Password"
                                v-model="formData.password"
                            />
                        </div>
                        <button
                            type="submit"
                            class="btn mt-3 btn-info btn-block"
                        >
                            Login
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import NavBar from "../components/NavBar.vue";
export default {
    name: "Login",
    data() {
        return {
            formData: {
                email: "",
                passowrd: "",
            },
        };
    },
    components: {
        NavBar,
    },
    methods: {
        async login() {
            await this.axios
                .post("login", this.formData)
                .then((response) => {
                    localStorage.setItem(
                        "auth_token",
                        response.data.data.token
                    );
                    if (response.data.data.user.role == "user") {
                        this.$router.push("/home");
                    } else {
                        this.$router.push("/dashboard");
                    }
                })
                .catch((errors) => {
                    this.$showFlattenedErrorsInMoshaToast(errors);
                });
        },
    },
};
</script>
