<?php 

namespace App\Traits;

trait HelperTrait {
    public function sendSuccess($message, $data = '')
    {
        return response()->json(['message' => $message, 'data' => $data], 200);
    }

    public function sendError($error_message, $code = 400, $data = null)
    {
        return response()->json(['message' => $error_message, 'data' => $data], $code);
    }
}