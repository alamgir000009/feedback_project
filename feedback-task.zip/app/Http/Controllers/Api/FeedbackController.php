<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Feedback;
use App\Traits\HelperTrait;
use Illuminate\Http\Request;

class FeedbackController extends Controller
{
    use HelperTrait;
    public function index()
    {
        $feedbacks = Feedback::with(['user', 'comments.user'])->get();

        return $this->sendSuccess("Register Successful", $feedbacks);
    }
    public function feedback(Request $request)
    {
        $validator = Validator($request->all(), [
            "category" => "required|string|min:5",
            "title" => "required|string",
            "description" => "required|string|min:20",
        ]);

        if ($validator->fails()) {
            return $this->sendError($validator->errors(), 422);
        }

        auth()->user()->feedbacks()->create($validator->valid());

        return $this->sendSuccess("Register Successfully");
    }
    public function feedbackComment(Request $request)
    {
        $validator = Validator($request->all(), [
            "feedback_id" => "required|exists:feedback,id",
            "comment" => "required|string"
        ]);

        if ($validator->fails()) {
            return $this->sendError($validator->errors(), 422);
        }
        
        auth()->user()->comments()->create([
            "comment" => $request->comment,
            "feedback_id" => $request->feedback_id
        ]);

        return $this->sendSuccess("Comment added Successfully");
    }

}
