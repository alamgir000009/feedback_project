<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use App\Traits\HelperTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    use HelperTrait;
    public function register(Request $request)
    {
        $validator = Validator($request->all(), [
            "name" => "required|string",
            "email" => ["required", "email", "unique:users,email"],
            "password" => ['required', 'string', 'min:3', 'confirmed'],
        ]);

        if ($validator->fails()) {
            return $this->sendError($validator->errors(), 422);
        }

        $user = User::create($validator->valid());

        $token = $user->createToken('API Token')->plainTextToken;
        $data = ["token" => $token, "user" => $user];

        return $this->sendSuccess("Register Successful", $data);
    }

    public function login(Request $request)
    {
        $validators = Validator($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);
        if ($validators->fails()) {
            return $this->sendError($validators->errors(), 422);
        }

        if (Auth::attempt($request->only('email', 'password'))) {
            $user = Auth::user();
            $token = $user->createToken('API Token')->plainTextToken;
            $data = ["token" => $token, "user" => $user];
            return $this->sendSuccess("Login Successful", $data);
        } else {
            return $this->sendError("Invalid Credentials", 421);
        }
    }
}
